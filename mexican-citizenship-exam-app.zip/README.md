# 🇲🇽 Examen de Naturalización Mexicana — App de Práctica

App web para practicar el **examen de naturalización mexicana**. Los usuarios se registran con su número de teléfono, y una pregunta se considera **dominada** cuando la contestan correctamente en **5 sesiones distintas** (5 días diferentes).

- **10 preguntas** de Cultura e Historia
- **6 preguntas** de Lectura
- **6 preguntas** de Conversación (práctica)
- Progreso guardado por número de teléfono
- Cada práctica cuenta como una sesión distinta

## Stack

- **Next.js 16** (App Router) + React 19
- **Tailwind CSS 4** para estilos
- **PostgreSQL** + **Drizzle ORM**
- **TypeScript**

## Estructura del proyecto

```
src/
├── app/
│   ├── page.tsx              # UI principal (login + práctica)
│   ├── layout.tsx            # Layout global
│   ├── globals.css           # Tailwind
│   └── api/
│       ├── auth/phone/       # Registro/login por teléfono
│       ├── day/              # Cargar preguntas por categoría
│       ├── submit/           # Enviar respuestas de una sesión
│       └── health/           # Healthcheck
├── db/
│   ├── index.ts              # Cliente Drizzle
│   └── schema.ts             # users, questions, user_progress
scripts/
└── seed.ts                   # Preguntas iniciales
```

## 🚀 Desplegar en producción (recomendado: Vercel + Neon)

La app es un **fullstack** (Next.js + Postgres). GitHub Pages **no funciona** aquí porque solo sirve HTML estático. Usa esto en su lugar:

### 1. Sube el código a GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/examen-naturalizacion.git
git push -u origin main
```

### 2. Crea una base de datos Postgres gratis en [Neon](https://neon.tech)

1. Ve a https://neon.tech → **Sign up** con GitHub
2. Crea un nuevo proyecto (elige región `us-east-1` o la más cercana)
3. Copia el **connection string** (empieza con `postgresql://`)

### 3. Despliega en [Vercel](https://vercel.com)

1. Ve a https://vercel.com → **Import Project** desde tu repo de GitHub
2. En **Environment Variables**, agrega:
   - `DATABASE_URL` = el connection string de Neon
3. Click **Deploy**

### 4. Inicializa la base de datos

Después del primer despliegue, corre estos comandos **localmente** apuntando a tu DB de Neon:

```bash
# 1. Copia .env.example a .env y pon tu DATABASE_URL de Neon
cp .env.example .env

# 2. Crea las tablas
npx drizzle-kit push

# 3. Carga las preguntas
npx tsx scripts/seed.ts
```

¡Listo! Tu app estará en `https://tu-app.vercel.app` y funciona para todos.

## 🖥️ Correr localmente

```bash
# 1. Instala dependencias
npm install

# 2. Configura Postgres local o remoto
cp .env.example .env
# Edita .env con tu DATABASE_URL

# 3. Crea tablas + carga preguntas
npx drizzle-kit push
npx tsx scripts/seed.ts

# 4. Arranca el servidor
npm run dev
```

Abre http://localhost:3000

## 📝 Añadir tus propias preguntas

Edita `scripts/seed.ts` y añade objetos al array:

```typescript
{
  cat: "cultura_historia", // o "lectura" o "conversacion"
  q: "Tu pregunta aquí",
  opts: ["Opción A", "Opción B", "Opción C", "Opción D"],
  correct: 1, // índice (0-based) de la respuesta correcta
  exp: "Explicación breve"
}
```

Luego corre:
```bash
psql $DATABASE_URL -c "TRUNCATE questions RESTART IDENTITY CASCADE;"
npx tsx scripts/seed.ts
```

O bien, sube tu **archivo .exe / .txt / .csv / .json** con las preguntas al repo (por ejemplo dentro de `data/`) y avísame para que escriba un script que lo lea y lo cargue automáticamente.

## 🧠 Sistema de dominio (mastery)

Una pregunta se considera **dominada** cuando el usuario:
1. Ha respondido **correctamente** a esa pregunta
2. En **5 sesiones distintas** (cada práctica cuenta como una sesión)

La barra de progreso muestra `X / 22 dominadas`. Cuando llega a 22, aparece el estado **"¡Estás listo para el examen!"**.

## 📄 Licencia

MIT — úsalo libremente, contribuye si quieres 🙌
