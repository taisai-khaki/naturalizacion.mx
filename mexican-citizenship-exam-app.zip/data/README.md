# Banco de preguntas

Sube aquí tu archivo con preguntas del examen. Formatos soportados:

- **JSON** (recomendado) → `questions.json`
- **TXT** → `questions.txt`
- **CSV** → `questions.csv`
- **EXE** → sube el `.exe` original y avisa: se puede extraer el texto con `strings` o abriéndolo con un descompilador

Después de subir el archivo, importa con:

```bash
npx tsx scripts/import-questions.ts data/questions.json
```

Consulta `scripts/import-questions.ts` para el formato exacto de cada tipo.

## Ejemplo JSON

```json
[
  {
    "category": "cultura_historia",
    "question": "¿Cuál es el nombre oficial de México?",
    "options": ["República de México", "Estados Unidos de México", "Nación Mexicana"],
    "correct": 1,
    "explanation": "El nombre oficial es Estados Unidos de México."
  }
]
```

Categorías válidas: `cultura_historia`, `lectura`, `conversacion`
