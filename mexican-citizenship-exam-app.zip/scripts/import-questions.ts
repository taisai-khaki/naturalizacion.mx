import "dotenv/config";
import { db } from "@/db";
import { questions } from "@/db/schema";
import * as fs from "fs";
import * as path from "path";

/**
 * Importa preguntas desde un archivo en `data/` (JSON, TXT o CSV).
 *
 * Uso:
 *   npx tsx scripts/import-questions.ts data/questions.json
 *   npx tsx scripts/import-questions.ts data/questions.txt
 *   npx tsx scripts/import-questions.ts data/questions.csv
 *
 * Formatos soportados:
 *
 * 1) JSON (más recomendado):
 * [
 *   {
 *     "category": "cultura_historia",  // o "lectura" o "conversacion"
 *     "question": "¿Cuál es la capital?",
 *     "options": ["Guadalajara", "CDMX", "Puebla", "Monterrey"],
 *     "correct": 1,
 *     "explanation": "La capital es Ciudad de México"
 *   }
 * ]
 *
 * 2) TXT (bloques separados por línea en blanco):
 * CATEGORY: cultura_historia
 * Q: ¿Cuál es la capital?
 * A) Guadalajara
 * B) CDMX
 * C) Puebla
 * D) Monterrey
 * CORRECT: B
 * EXP: La capital es Ciudad de México
 *
 * 3) CSV (con encabezado):
 * category,question,optionA,optionB,optionC,optionD,correct,explanation
 * cultura_historia,¿Capital?,Guadalajara,CDMX,Puebla,Monterrey,B,La capital es CDMX
 */

type QRow = { category: string; question: string; options: string[]; correct: number; explanation?: string };

function parseJson(txt: string): QRow[] {
  const data = JSON.parse(txt);
  if (!Array.isArray(data)) throw new Error("JSON debe ser un array de preguntas");
  return data.map((d: any) => ({
    category: d.category || d.cat,
    question: d.question || d.q || d.questionText,
    options: d.options || d.opts,
    correct: typeof d.correct === "number" ? d.correct : parseInt(d.correct),
    explanation: d.explanation || d.exp || null,
  }));
}

function parseTxt(txt: string): QRow[] {
  const blocks = txt.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  const rows: QRow[] = [];
  for (const b of blocks) {
    const lines = b.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    let cat = "cultura_historia", q = "", exp = "";
    const opts: string[] = [];
    let correctLetter = "A";
    for (const line of lines) {
      if (/^CATEGORY\s*:/i.test(line)) cat = line.split(":").slice(1).join(":").trim();
      else if (/^Q\s*:/i.test(line) || /^QUESTION\s*:/i.test(line) || /^PREGUNTA\s*:/i.test(line)) q = line.split(":").slice(1).join(":").trim();
      else if (/^[A-Z][\)\.\-:]/.test(line)) opts.push(line.replace(/^[A-Z][\)\.\-:]\s*/, "").trim());
      else if (/^CORRECT\s*:/i.test(line) || /^RESPUESTA\s*:/i.test(line)) correctLetter = line.split(":").slice(1).join(":").trim().toUpperCase();
      else if (/^EXP\s*:/i.test(line) || /^EXPLANATION\s*:/i.test(line) || /^EXPLICACION\s*:/i.test(line)) exp = line.split(":").slice(1).join(":").trim();
    }
    if (!q || opts.length === 0) continue;
    const correct = correctLetter.charCodeAt(0) - 65;
    rows.push({ category: cat, question: q, options: opts, correct, explanation: exp || undefined });
  }
  return rows;
}

function parseCsv(txt: string): QRow[] {
  const lines = txt.split(/\r?\n/).filter((l) => l.trim());
  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const rows: QRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = splitCsvLine(lines[i]);
    const rec: Record<string, string> = {};
    header.forEach((h, idx) => (rec[h] = (cols[idx] || "").trim()));
    const opts: string[] = [];
    for (const key of ["optiona", "optionb", "optionc", "optiond", "optione"]) {
      if (rec[key]) opts.push(rec[key]);
    }
    if (!opts.length && rec.options) opts.push(...rec.options.split("|"));
    const correctVal = (rec.correct || "A").toUpperCase();
    const correct = /^\d+$/.test(correctVal) ? parseInt(correctVal) : correctVal.charCodeAt(0) - 65;
    rows.push({
      category: rec.category || "cultura_historia",
      question: rec.question || rec.pregunta,
      options: opts,
      correct,
      explanation: rec.explanation || rec.explicacion || undefined,
    });
  }
  return rows;
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "", inQuote = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
    else if (c === '"') inQuote = !inQuote;
    else if (c === "," && !inQuote) { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out;
}

async function main() {
  const filepath = process.argv[2];
  if (!filepath) {
    console.error("Uso: npx tsx scripts/import-questions.ts <archivo.json|.txt|.csv>");
    process.exit(1);
  }
  const full = path.resolve(filepath);
  if (!fs.existsSync(full)) { console.error("Archivo no existe:", full); process.exit(1); }
  const txt = fs.readFileSync(full, "utf-8");
  const ext = path.extname(full).toLowerCase();

  let rows: QRow[];
  if (ext === ".json") rows = parseJson(txt);
  else if (ext === ".csv") rows = parseCsv(txt);
  else rows = parseTxt(txt);

  console.log(`Encontradas ${rows.length} preguntas en ${filepath}`);
  let inserted = 0;
  for (const r of rows) {
    if (!r.question || !r.options.length || isNaN(r.correct)) continue;
    await db.insert(questions).values({
      category: r.category,
      questionText: r.question,
      options: r.options,
      correctAnswer: r.correct,
      explanation: r.explanation || null,
      difficulty: 1,
      isActive: true,
    });
    inserted++;
  }
  console.log(`✅ Insertadas ${inserted} preguntas.`);
}

main().catch((e) => { console.error(e); process.exit(1); });
