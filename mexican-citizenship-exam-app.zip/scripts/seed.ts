import "dotenv/config";
import { db } from "@/db";
import { questions } from "@/db/schema";

async function seed() {
  const data = [
    // ===== CULTURA E HISTORIA (10 preguntas examen) =====
    { cat: "cultura_historia", q: "¿Cuál es el nombre oficial de México?", opts: ["República de México","Estados Unidos de México","Nación Mexicana","Confederación Mexicana"], correct: 1, exp: "Nombre oficial: Estados Unidos de México." },
    { cat: "cultura_historia", q: "¿En qué año se obtuvo la independencia?", opts: ["1810","1821","1910","1848"], correct: 1, exp: "Independencia en 1821, Plan de Iguala." },
    { cat: "cultura_historia", q: "¿Quién inició el Grito de Dolores?", opts: ["Benito Juárez","Miguel Hidalgo","Porfirio Díaz","Emilio Carranza"], correct: 1, exp: "Miguel Hidalgo, sacerdote, el 16 sept 1810." },
    { cat: "cultura_historia", q: "¿Qué representa el escudo nacional (águila, nopal, serpiente)?", opts: ["Victoria en guerra","Fundación de Tenochtitlan","Independencia","Paz"], correct: 1, exp: "Fundación de Tenochtitlan según la leyenda." },
    { cat: "cultura_historia", q: "¿Cuál es la moneda oficial?", opts: ["Peso","Dólar","Real","Bolívar"], correct: 0, exp: "El peso mexicano (MXN)." },
    { cat: "cultura_historia", q: "¿Cuál es el día de la independencia?", opts: ["5 mayo","16 septiembre","20 noviembre","1 mayo"], correct: 1, exp: "16 de septiembre, Grito de Dolores." },
    { cat: "cultura_historia", q: "¿Qué fiesta celebra la Batalla de Puebla?", opts: ["5 mayo","16 septiembre","20 noviembre","1 enero"], correct: 0, exp: "5 de mayo = Batalla de Puebla (1862)." },
    { cat: "cultura_historia", q: "¿Cuál es la capital de México?", opts: ["Guadalajara","Monterrey","Ciudad de México","Puebla"], correct: 2, exp: "CDMX es la capital federal." },
    { cat: "cultura_historia", q: "¿Cuál es el nombre del río más largo?", opts: ["Río Lerma","Río Bravo","Río Balsas","Río Usumacinta"], correct: 0, exp: "Río Lerma (~708 km)." },
    { cat: "cultura_historia", q: "¿Qué tipo de gobierno tiene México?", opts: ["Monarquía","Dictadura","República federal democrática","Estado comunista"], correct: 2, exp: "República federal representativa y democrática." },

    // ===== LECTURA (6 preguntas examen) =====
    { cat: "lectura", q: "Lea: 'México es diversa con 32 estados. La capital es CDMX.' ¿Capital?", opts: ["Guadalajara","Monterrey","Ciudad de México","Puebla"], correct: 2, exp: "El texto dice claramente CDMX." },
    { cat: "lectura", q: "Lea: 'El Día de Muertos es 1 y 2 noviembre. Se honran fallecidos.' ¿Fecha?", opts: ["25 dic","1-2 nov","15 sep","5 mayo"], correct: 1, exp: "Texto indica 1 y 2 de noviembre." },
    { cat: "lectura", q: "Lea: 'México tiene 126 millones de habitantes. Es el país hispanohablante más grande.' ¿Población?", opts: ["90M","126M","200M","60M"], correct: 1, exp: "Más de 126 millones según texto." },
    { cat: "lectura", q: "Lea: 'La Revolución comenzó en 1910 por justicia social.' ¿Año?", opts: ["1810","1910","1940","1821"], correct: 1, exp: "1910 según texto." },
    { cat: "lectura", q: "Lea: 'La Constitución de 1917 fue inspirada por la Revolución.' ¿Año?", opts: ["1810","1917","1920","1940"], correct: 1, exp: "1917, promulgada ese año." },
    { cat: "lectura", q: "Lea: 'La gastronomía mexicana es Patrimonio Cultural Inmaterial de UNESCO.' ¿Reconocimiento?", opts: ["Premio Nobel","Patrimonio UNESCO","Premio Oscar","Medalla oro"], correct: 1, exp: "Declarada Patrimonio Cultural Inmaterial." },

    // ===== CONVERSACIÓN (6 de práctica) =====
    { cat: "conversacion", q: "¿Cómo saluda formalmente a mayor?", opts: ["¿Qué onda?","Buenos días","¿Qué pasó?","¿Cómo estás? (informal)"], correct: 1, exp: "'Buenos días / Buenas tardes' es formal." },
    { cat: "conversacion", q: "Para pedir cuenta en restaurante:", opts: ["La cuenta, por favor","Quiero pagar","¿Cuánto cuesta?","Dame la cuenta"], correct: 0, exp: "Se dice 'La cuenta, por favor'." },
    { cat: "conversacion", q: "¿Qué significa '¿Cómo te va?'?", opts: ["¿Cómo estás formal?","¿Cómo estás informal?","¿Dónde estás?","¿Qué trabajo?"], correct: 1, exp: "Forma informal de preguntar cómo le va." },
    { cat: "conversacion", q: "Para pedir ayuda cortésmente:", opts: ["¡Ayuda!","¿Me puede ayudar, por favor?","¿Qué pasa?","¿Dónde están?"], correct: 1, exp: "Cortesía: '¿Me puede ayudar, por favor?'" },
    { cat: "conversacion", q: "Presentación formal:", opts: ["Soy...","Me llamo...","Me llamo / Mi nombre es...","Todas"], correct: 3, exp: "Todas son correctas para presentarse." },
    { cat: "conversacion", q: "¿Cómo dices 'Gracias' muy agradecido?", opts: ["Gracias","Muchísimas gracias","Gracias nomás","De nada"], correct: 1, exp: "'Muchísimas gracias' es muy agradecido." },
  ];

  for (const q of data) {
    await db.insert(questions).values({
      category: q.cat,
      questionText: q.q,
      options: q.opts,
      correctAnswer: q.correct,
      explanation: q.exp,
      difficulty: 1,
      isActive: true,
    });
  }
  console.log(`Seeded ${data.length} questions.`);
}
seed().catch(console.error);
