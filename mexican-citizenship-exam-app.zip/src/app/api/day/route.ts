import { db } from "@/db";
import { questions, userProgress } from "@/db/schema";
import { sql, eq, and } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const userId = url.searchParams.get("userId");
    const category = url.searchParams.get("category");
    if (!userId) return NextResponse.json({ error: "userId required" }, { status: 400 });
    const uid = parseInt(userId);

    const qs = category && category !== "all"
      ? await db.select().from(questions).where(and(eq(questions.category, category), eq(questions.isActive, true)))
      : await db.select().from(questions).where(eq(questions.isActive, true));

    const progressRows = await db.select({ questionId: userProgress.questionId, sessionDay: userProgress.sessionDay, isCorrect: userProgress.isCorrect })
      .from(userProgress).where(eq(userProgress.userId, uid));

    // Build mastery map: questionId -> number of distinct correct session days
    const masteryMap = new Map<number, number>();
    const correctDays = new Map<string, Set<number>>(); // key = userId-questionId
    for (const row of progressRows) {
      if (row.isCorrect) {
        const key = `${uid}-${row.questionId}`;
        if (!correctDays.has(key)) correctDays.set(key, new Set());
        correctDays.get(key)!.add(row.sessionDay);
      }
    }
    for (const [key, set] of correctDays) {
      const qId = parseInt(key.split("-")[1]);
      masteryMap.set(qId, set.size);
    }

    const results = qs.map((q) => ({
      ...q,
      masteredDays: masteryMap.get(q.id) || 0,
      isMastered: (masteryMap.get(q.id) || 0) >= 5,
    }));

    return NextResponse.json({ questions: results, total: qs.length });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
