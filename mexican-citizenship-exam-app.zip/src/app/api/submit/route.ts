import { db } from "@/db";
import { users, questions, userProgress } from "@/db/schema";
import { sql, eq, and } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { userId, answers, sessionDay } = await req.json();
    if (!userId || !Array.isArray(answers)) return NextResponse.json({ error: "Invalid" }, { status: 400 });
    const uid = parseInt(userId);
    if (!uid) return NextResponse.json({ error: "Bad user" }, { status: 400 });

    // Get current session from user if not provided
    const userRow = await db.select({ practiceSession: users.practiceSession }).from(users).where(eq(users.id, uid)).limit(1);
    let currentSession = userRow[0]?.practiceSession || 0;
    if (!sessionDay) currentSession += 1;
    else currentSession = parseInt(sessionDay);

    let correctCount = 0;
    for (const item of answers) {
      const qId = item.questionId || item.id;
      const userAns = item.answerIndex ?? item.userAnswer;
      if (qId == null || userAns == null) continue;
      const qRow = await db.select({ correctAnswer: questions.correctAnswer, category: questions.category }).from(questions).where(eq(questions.id, qId)).limit(1);
      if (!qRow.length) continue;
      const isCorrect = qRow[0].correctAnswer === userAns;
      if (isCorrect) correctCount++;
      await db.execute(sql`
        INSERT INTO user_progress (user_id, question_id, session_day, is_correct, answered_at)
        VALUES (${uid}, ${qId}, ${currentSession}, ${isCorrect}, NOW())
      `);
    }

    // Update stats: total correct answers (count of correct progress rows for user)
    const stats = await db.execute(sql`
      SELECT COUNT(*) as total_answered, SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) as total_correct FROM user_progress WHERE user_id = ${uid}
    `);
    const s = stats.rows[0] as any;
    const totalAnswered = parseInt(s.total_answered || 0);
    const totalCorrect = parseInt(s.total_correct || 0);

    // Mastered = distinct questions with >=5 distinct correct session days
    const masteredRow = await db.execute(sql`
      SELECT COUNT(DISTINCT question_id) as mastered FROM (
        SELECT question_id FROM user_progress WHERE user_id = ${uid} AND is_correct = true GROUP BY question_id HAVING COUNT(DISTINCT session_day) >= 5
      ) t
    `);
    const masteredCount = parseInt((masteredRow.rows[0] as any).mastered || 0);
    const totalQuestions = await db.execute(sql`SELECT COUNT(*) as cnt FROM questions WHERE is_active = true`);
    const totalQ = parseInt((totalQuestions.rows[0] as any).cnt || 0);
    const isReady = masteredCount >= totalQ; // fully ready when all learned

    await db.update(users).set({
      totalCorrect,
      totalAnswered,
      masteredCount,
      isReady,
      practiceSession: Math.max(currentSession, userRow[0]?.practiceSession || 0),
      lastActive: new Date(),
    }).where(eq(users.id, uid));

    const updated = await db.select().from(users).where(eq(users.id, uid)).limit(1);
    return NextResponse.json({ submitted: answers.length, correct: correctCount, sessionDay: currentSession, masteredCount, isReady, user: updated[0] || null });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
