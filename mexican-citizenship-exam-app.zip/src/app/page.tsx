"use client";

import { useState, useEffect } from "react";
import {
  Landmark, BookOpen, MessageCircle, Phone, Trophy, Sparkles,
  CheckCircle2, ArrowRight, ChevronDown, ShieldCheck, Zap
} from "lucide-react";

const CATS: Record<string, { label: string; icon: typeof Landmark; color: string; bg: string; total: number }> = {
  cultura_historia: { label: "Cultura e Historia", icon: Landmark, color: "text-emerald-700", bg: "bg-emerald-50", total: 10 },
  lectura: { label: "Lectura", icon: BookOpen, color: "text-amber-700", bg: "bg-amber-50", total: 6 },
  conversacion: { label: "Conversación", icon: MessageCircle, color: "text-rose-700", bg: "bg-rose-50", total: 6 },
};

export default function ExamApp() {
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [cat, setCat] = useState("cultura_historia");
  const [questions, setQuestions] = useState<any[]>([]);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState<Record<number, boolean>>({});
  const [result, setResult] = useState<string>("");
  const [showResult, setShowResult] = useState(false);

  async function login() {
    if (!phone.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/auth/phone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), name: name.trim() || undefined }),
      });
      const data = await res.json();
      if (data.user) {
        setUser(data.user);
        await loadCat("cultura_historia");
      }
    } catch (e) { alert("Error al entrar"); }
    finally { setLoading(false); }
  }

  async function loadCat(category: string) {
    if (!user) return;
    setCat(category);
    setLoading(true);
    try {
      const res = await fetch(`/api/day?userId=${user.id}&category=${category}`);
      const data = await res.json();
      setQuestions(data.questions || []);
      setAnswers({});
      setSubmitted({});
      setShowResult(false);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  function pick(qId: number, idx: number) {
    if (submitted[qId]) return;
    setAnswers((prev) => ({ ...prev, [qId]: idx }));
  }

  async function submit() {
    if (!user) return;
    const list = questions.map((q) => ({ questionId: q.id, answerIndex: answers[q.id] })).filter((a) => a.answerIndex != null);
    if (list.length === 0) return alert("Responde al menos una pregunta.");
    setLoading(true);
    try {
      const res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, answers: list }),
      });
      const data = await res.json();
      if (data.user) setUser(data.user);
      setResult(`Correctas: ${data.correct}/${list.length} • Dominadas: ${data.masteredCount}`);
      setShowResult(true);
      await loadCat(cat); // refresh mastery
    } catch (e) { alert("Error al enviar"); }
    finally { setLoading(false); }
  }

  // On initial login, load first category
  useEffect(() => {
    if (user) loadCat("cultura_historia");
  }, [user?.id]);

  if (!user) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-emerald-950 via-emerald-900 to-green-950 text-white flex flex-col items-center justify-center px-6">
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 20% 30%, #BFBF00 0%, transparent 45%), radial-gradient(circle at 80% 70%, #CE1126 0%, transparent 45%)" }} />
        <div className="relative z-10 text-center max-w-xl w-full">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-1.5 text-sm font-medium text-amber-200 mb-6 border border-white/10"><Sparkles className="w-4 h-4" /> Práctica de naturalización mexicana</div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.1] mb-4 bg-gradient-to-b from-white via-amber-100 to-amber-300 bg-clip-text text-transparent">Examen <span className="italic font-serif">de Naturalización</span></h1>
          <p className="text-lg md:text-xl text-emerald-100/90 mb-10 leading-relaxed">10 Cultura/Historia + 6 Lectura + Conversación. Una pregunta se domina con <strong>5 correctas en 5 días distintos</strong>.</p>
          <form onSubmit={(e) => { e.preventDefault(); login(); }} className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-8 md:p-10 shadow-2xl shadow-black/40 text-left max-w-md mx-auto">
            <label htmlFor="phone" className="block text-sm font-medium text-emerald-100 mb-1">Número de teléfono</label>
            <div className="relative mb-4"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-300" /><input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+52 55 1234 5678" className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-emerald-300/60 focus:outline-none focus:ring-2 focus:ring-amber-300/50 transition" /></div>
            <label htmlFor="name" className="block text-sm font-medium text-emerald-100 mb-1">Tu nombre (opcional)</label>
            <div className="relative mb-5"><BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-300" /><input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Juan Pérez" className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-emerald-300/60 focus:outline-none focus:ring-2 focus:ring-amber-300/50 transition" /></div>
            <button type="submit" disabled={loading || !phone.trim()} className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-300 to-amber-500 text-emerald-950 font-extrabold text-lg shadow-lg hover:brightness-110 transition flex items-center justify-center gap-2 disabled:opacity-60">{loading ? "Entrando..." : "Entrar / Registrarme"} <ArrowRight className="w-5 h-5" /></button>
          </form>
          <p className="mt-8 text-emerald-300/60 text-sm">Tu progreso se guarda por teléfono. Regresa cuando quieras practicar.</p>
        </div>
      </main>
    );
  }

  const masteredTotal = Math.round(((user.masteredCount || 0) / 22) * 100);
  const correctTotal = user.totalCorrect || 0;

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-emerald-900 to-green-950 text-white">
      <header className="sticky top-0 z-30 bg-emerald-950/70 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-300 to-rose-400 flex items-center justify-center shadow-lg shadow-amber-900/20"><Landmark className="w-5 h-5 text-emerald-950" /></div>
            <div><h2 className="font-extrabold leading-none text-base tracking-tight">Naturalización <span className="text-amber-300">MX</span></h2><div className="text-[10px] text-emerald-300/70 font-medium leading-none mt-0.5">Examen de Ciudadanía</div></div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline text-xs font-medium bg-white/10 px-2.5 py-1 rounded-full border border-white/10">{user.phone}</span>
            <button onClick={() => { setUser(null); setPhone(""); setName(""); }} className="text-xs bg-white/5 hover:bg-white/10 border border-white/10 px-3 py-1.5 rounded-full transition">Salir</button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        {/* Stats */}
        <section className="mb-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-6">
            <div>
              <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight mb-2">Hola, {user.name || "estudiante"}</h1>
              <p className="text-emerald-200/80 text-base md:text-lg">Practica hasta dominar cada pregunta (5 correctas en 5 días distintos).</p>
            </div>
            <div className="bg-white/5 border border-white/10 backdrop-blur rounded-2xl p-5 min-w-[220px] shadow-xl shadow-black/20">
              <div className="flex items-center gap-2 mb-3 text-amber-200"><Trophy className="w-5 h-5" /> <span className="font-bold">Progreso</span></div>
              <div className="flex items-end gap-3 mb-2"><span className="text-4xl font-extrabold leading-none">{user.masteredCount || 0}<span className="text-xl text-emerald-300">/22</span></span></div>
              <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden"><div className="h-full bg-gradient-to-r from-amber-300 to-rose-400 rounded-full transition-all duration-700" style={{ width: `${masteredTotal}%` }} /></div>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Dominadas", value: `${user.masteredCount || 0} / 22`, sub: "5 días correctos cada una", icon: ShieldCheck, color: "bg-emerald-500/10 text-emerald-300" },
              { label: "Correctas totales", value: correctTotal, sub: "Respuestas correctas", icon: CheckCircle2, color: "bg-amber-500/10 text-amber-300" },
              { label: "Sesión actual", value: `#${(user.practiceSession || 0) + 1}`, sub: "Cada práctica cuenta como día", icon: Zap, color: "bg-rose-500/10 text-rose-300" },
              { label: "Estado", value: user.isReady ? "¡Listo!" : "En progreso", sub: user.isReady ? "Todas dominadas" : "Sigue practicando", icon: Sparkles, color: user.isReady ? "bg-amber-400/10 text-amber-300" : "bg-emerald-500/10 text-emerald-300" },
            ].map((s) => (
              <div key={s.label} className="bg-white/5 border border-white/10 rounded-2xl p-5 hover:bg-white/[0.07] transition"><div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${s.color}`}><s.icon className="w-5 h-5" /></div><div className="text-2xl font-extrabold leading-none mb-1">{s.value}</div><div className="text-xs font-medium text-emerald-200/70">{s.sub}</div></div>
            ))}
          </div>
        </section>

        {user.isReady && (
          <section className="mb-10 relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-300 to-rose-400 text-emerald-950 p-8 md:p-10 shadow-2xl shadow-amber-900/20">
            <div className="absolute top-[-40%] right-[-20%] w-[500px] h-[500px] bg-white/20 rounded-full blur-3xl" />
            <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
              <div className="bg-white/20 p-4 rounded-2xl shadow-inner"><Trophy className="w-12 h-12" /></div>
              <div><h2 className="text-3xl md:text-4xl font-extrabold mb-2">¡Estás completamente listo!</h2><p className="text-lg font-medium opacity-90 max-w-2xl">Dominas las 22 preguntas del examen con 5 respuestas correctas en 5 sesiones distintas. ¡Mucha suerte en tu examen de naturalización!</p></div>
            </div>
          </section>
        )}

        {/* Category tabs */}
        <section>
          <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
            {Object.entries(CATS).map(([key, info]) => (
              <button key={key} onClick={() => loadCat(key)} className={`flex items-center gap-2 px-4 py-3 rounded-2xl font-bold text-sm whitespace-nowrap transition shadow-md border ${cat === key ? "bg-gradient-to-r from-amber-300 to-rose-400 text-emerald-950 border-transparent scale-105" : "bg-white/5 text-emerald-100 border-white/10 hover:bg-white/10"}`}>
                <info.icon className="w-4 h-4" /> {info.label} <span className="text-xs opacity-60 font-medium">({info.total})</span>
              </button>
            ))}
          </div>

          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight mb-6">{CATS[cat].label}</h2>

          <div className="grid gap-6">
            {questions.map((q: any) => {
              const Icon = CATS[cat].icon;
              const correct = q.correctAnswer;
              const opts = Array.isArray(q.options) ? q.options : [];
              const selected = answers[q.id];
              const done = submitted[q.id];
              const daysCorrect = q.masteredDays || 0;
              const isMastered = q.isMastered;
              const progress = Math.round((daysCorrect / 5) * 100);

              return (
                <article key={q.id} className="bg-gradient-to-b from-white/[0.07] to-white/[0.03] border border-white/10 rounded-3xl overflow-hidden shadow-2xl shadow-black/20 backdrop-blur-sm">
                  <div className={`flex items-center gap-3 px-6 py-4 border-b border-white/5 ${CATS[cat].bg}`}>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-md ${CATS[cat].color} bg-white/10`}><Icon className="w-5 h-5" /></div>
                    <div className="flex-1"><div className="font-extrabold text-sm leading-none flex items-center gap-2">Pregunta <span className="text-xs font-bold bg-white/10 px-2 py-0.5 rounded-md border border-white/10">{String.fromCharCode(65 + (questions.indexOf(q) % 26))}</span></div>
                      <div className="text-[10px] text-emerald-300/60 font-medium uppercase tracking-widest mt-0.5">{isMastered ? "✓ Dominada" : `${daysCorrect}/5 días correctos`}</div>
                    </div>
                    <div className="w-12 text-right">
                      <div className="text-xl font-extrabold leading-none">{daysCorrect}<span className="text-xs text-emerald-300/50">/5</span></div>
                      <div className="w-full bg-white/10 rounded-full h-1.5 mt-1 overflow-hidden"><div className="h-full bg-gradient-to-r from-amber-300 to-rose-400 rounded-full" style={{ width: `${progress}%` }} /></div>
                    </div>
                  </div>
                  <div className="p-6 md:p-8">
                    <h3 className="text-xl md:text-2xl font-extrabold leading-snug mb-6">{q.questionText}</h3>
                    <div className="grid gap-3">
                      {opts.map((opt: string, idx: number) => {
                        const isCorrect = idx === correct;
                        const isSelected = selected === idx;
                        const showCorrect = done && isCorrect;
                        const showWrong = done && isSelected && !isCorrect;
                        return (
                          <button key={idx} onClick={() => pick(q.id, idx)} disabled={done} className={`text-left px-5 py-4 rounded-2xl border-2 transition flex items-center gap-3 font-medium text-base md:text-lg shadow-sm ${showCorrect ? "bg-emerald-500/15 border-emerald-400 text-emerald-200" : showWrong ? "bg-rose-500/10 border-rose-400/70 text-rose-200" : isSelected ? "bg-amber-300/15 border-amber-300 text-amber-50" : "bg-white/5 border-white/10 text-emerald-50 hover:bg-white/10 hover:border-white/20"}`}>
                            <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-extrabold shrink-0 border-2 ${showCorrect ? "bg-emerald-400 text-emerald-950 border-emerald-400" : showWrong ? "bg-rose-400 text-rose-950 border-rose-400" : isSelected ? "bg-amber-300 text-amber-950 border-amber-300" : "bg-white/5 text-emerald-200 border-white/10"}`}>{String.fromCharCode(65 + idx)}</span>
                            <span>{opt}</span>
                            {showCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-300 ml-auto shrink-0" />}
                            {showWrong && <span className="ml-auto text-xs font-bold text-rose-300">Incorrecto</span>}
                          </button>
                        );
                      })}
                    </div>
                    {done && q.explanation && (
                      <div className="mt-5 bg-amber-400/10 border border-amber-300/30 rounded-2xl p-5 text-sm leading-relaxed text-amber-100">
                        <strong className="text-amber-200 block mb-1">Explicación:</strong>{q.explanation}
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>

          {/* Actions */}
          <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 justify-between">
            <div className="text-sm text-emerald-200/70">Responde las preguntas y envía para registrar esta sesión de práctica.</div>
            <button onClick={submit} disabled={loading || Object.keys(answers).length === 0} className="px-8 py-3.5 bg-gradient-to-r from-amber-300 to-rose-400 text-emerald-950 font-extrabold rounded-2xl shadow-xl shadow-amber-900/30 hover:brightness-110 transition disabled:opacity-50 flex items-center gap-2">{loading ? "Enviando..." : "Enviar sesión"} <ArrowRight className="w-5 h-5" /></button>
          </div>

          {showResult && (
            <div className="mt-6 bg-gradient-to-r from-emerald-500/10 to-amber-400/10 border border-amber-300/20 rounded-3xl p-8 text-center shadow-2xl shadow-black/20">
              <h3 className="text-2xl font-extrabold mb-2">{result}</h3>
              <p className="text-lg text-emerald-200 font-medium">Cada respuesta correcta cuenta. Regresa mañana con tu teléfono para seguir dominando.</p>
              <button onClick={() => { setAnswers({}); setSubmitted({}); setShowResult(false); }} className="mt-6 px-6 py-3 bg-amber-300 text-emerald-950 font-extrabold rounded-xl hover:brightness-110 shadow-lg">Practicar de nuevo esta categoría</button>
            </div>
          )}
        </section>

        <footer className="mt-20 pt-10 border-t border-white/10 text-center text-emerald-300/50 text-sm">
          <p>Practica para el examen de naturalización de México. Sistema de dominio: 5 correctas en 5 sesiones distintas por pregunta.</p>
          <p className="mt-2 font-medium text-emerald-200/30">Código abierto en GitHub • Hecho para estudiantes de ciudadanía mexicana</p>
        </footer>
      </main>
    </div>
  );
}
