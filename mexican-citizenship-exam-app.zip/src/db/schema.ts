import { pgTable, serial, text, integer, timestamp, boolean, jsonb, index } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull().unique(),
  name: text("name"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  totalCorrect: integer("total_correct").default(0).notNull(),
  totalAnswered: integer("total_answered").default(0).notNull(),
  masteredCount: integer("mastered_count").default(0).notNull(),
  isReady: boolean("is_ready").default(false).notNull(),
  lastActive: timestamp("last_active", { withTimezone: true }).defaultNow().notNull(),
  practiceSession: integer("practice_session").default(0).notNull(), // se incrementa cada vez que practica
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // 'cultura_historia', 'lectura', 'conversacion'
  questionText: text("question_text").notNull(),
  options: jsonb("options").notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  explanation: text("explanation"),
  difficulty: integer("difficulty").default(1).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
}, (table) => [
  index("questions_category_idx").on(table.category),
]);

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  questionId: integer("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  sessionDay: integer("session_day").notNull(), // número de sesión (cada práctica cuenta como un día distinto)
  isCorrect: boolean("is_correct").notNull(),
  answeredAt: timestamp("answered_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  index("progress_user_idx").on(table.userId),
  index("progress_user_question_session_idx").on(table.userId, table.questionId, table.sessionDay),
]);
